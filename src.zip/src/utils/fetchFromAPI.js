import axios from 'axios';

const BASE_URL = 'https://youtube-v31.p.rapidapi.com'

const API_KEY = 'c4d59dfbdbmshd9e72b39b3369afp1d8918jsn45f5174a9727'

const options = {
  params: {
    maxResults: '50'
  },
  headers: {
    'X-RapidAPI-Key': API_KEY,
    'X-RapidAPI-Host': 'youtube-v31.p.rapidapi.com'
  }
};

export const fetchFromAPI = async (url) => {
  try {
    const { data } = await axios.get(`${BASE_URL}/${url}`, options);
       
    if (data && data.items) {
      return (data.items);
    } else {
      throw new Error('Invalid response format: missing items property');
    }
  } catch(error) {
    console.log('Error fetching data from API:', error)
  }
}

// export const fetchFromAPI = async (url) => {
//   try {
//     const response = await axios.get(`${BASE_URL}/${url}`, options);
    
//     if (response.data && response.data.items) {
//       return response.data.items;
//     } else {
//       throw new Error('Invalid response format: missing items property');
//     }
//   } catch (error) {
//     console.error('Error fetching data from API:', error);
//     // You might want to handle the error further here, e.g., show a message to the user
//     throw error; // Re-throw the error to propagate it to the caller
//   }
// };
